import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css',
})
export class TripCard {
  @Input('trip') trip!: Trip;
  @Output() tripDeleted = new EventEmitter<string>();

  constructor(private router: Router, private tripDataService: TripData) {}

  public editTrip(trip: Trip): void {
    localStorage.setItem('tripCode', trip.code);
    this.router.navigate(['/edit-trip']);
  }

  public deleteTrip(trip: Trip): void {
    if (confirm('Are you sure you want to delete "' + trip.name + '"?')) {
      this.tripDataService.deleteTrip(trip.code)
        .subscribe({
          next: () => {
            this.tripDeleted.emit(trip.code);
          },
          error: (error: any) => {
            console.log('Error: ' + error);
          }
        });
    }
  }
}
