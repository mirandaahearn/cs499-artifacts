const mongoose = require('mongoose');
const Trip = require('./travlr');
const fs = require('fs');

const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;

mongoose.connect(dbURI)
  .then(() => {
    console.log('Connected to MongoDB');
    const trips = JSON.parse(fs.readFileSync('../data/trips.json', 'utf8'));
    return Trip.deleteMany({})
      .then(() => Trip.insertMany(trips))
      .then(() => {
        console.log('Database seeded successfully');
        mongoose.connection.close();
      });
  })
  .catch(err => {
    console.log('Error:', err);
    mongoose.connection.close();
  });
