const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

const tripsList = async(req, res) => {
  const q = await Trip
    .find({})
    .exec();
  if (!q) {
    return res.status(404).json(err);
  } else {
    return res.status(200).json(q);
  }
};

const tripsReadOne = async(req, res) => {
  const q = await Trip
    .findOne({'code': req.params.tripCode})
    .exec();
  if (!q) {
    return res.status(404).json(err);
  } else {
    return res.status(200).json(q);
  }
};

// POST: /api/trips - Adds a new Trip
const tripsAddTrip = async(req, res) => {
  const q = await Trip.create({
    code: req.body.code,
    name: req.body.name,
    length: req.body.length,
    start: req.body.start,
    resort: req.body.resort,
    perPerson: req.body.perPerson,
    image: req.body.image,
    description: req.body.description
  });

  if (!q) {
    return res.status(400).json(err);
  } else {
    return res.status(201).json(q);
  }
};

// PUT: /api/trips/:tripCode - Updates an existing Trip
const tripsUpdateTrip = async(req, res) => {
  const q = await Trip
    .findOneAndUpdate(
      { 'code': req.params.tripCode },
      {
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
      }
    )
    .exec();

  if (!q) {
    return res.status(400).json(err);
  } else {
    return res.status(201).json(q);
  }
};

// DELETE: /api/trips/:tripCode - Removes a Trip
const tripsDeleteTrip = async(req, res) => {
  const q = await Trip
    .findOneAndDelete({ 'code': req.params.tripCode })
    .exec();

  if (!q) {
    return res.status(404).json({ message: 'Trip not found' });
  } else {
    return res.status(200).json({ message: 'Trip deleted', trip: q });
  }
};

module.exports = { tripsList, tripsReadOne, tripsAddTrip, tripsUpdateTrip, tripsDeleteTrip };
