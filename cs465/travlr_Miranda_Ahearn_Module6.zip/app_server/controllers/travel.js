const tripsEndpoint = 'http://localhost:3000/api/trips';
const options = {
  method: 'GET',
  headers: {
    'Accept': 'application/json'
  }
}

const travel = async(req, res) => {
  await fetch(tripsEndpoint, options)
    .then(res => res.json())
    .then(json => {
      let message = null;
      if (!json || !Array.isArray(json)) {
        message = 'API lookup error';
      } else if (json.length === 0) {
        message = 'No trips exist in database';
      }
      res.render('travel', {
        title: 'Travlr Getaways',
        trips: json,
        message
      });
    })
    .catch(err => res.status(500).send(err.message));
};

module.exports = { travel };
