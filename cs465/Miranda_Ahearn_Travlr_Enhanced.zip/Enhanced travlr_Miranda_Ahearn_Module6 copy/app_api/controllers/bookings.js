const mongoose = require('mongoose');
const Trip = mongoose.model('trips');
const Booking = mongoose.model('bookings');

// POST /api/bookings
// Creates a new booking linked to an existing trip by tripCode
const createBooking = async (req, res) => {
  const { guestName, guestEmail, numGuests, tripCode } = req.body;

  if (!guestName || !guestEmail || !numGuests || !tripCode) {
    return res.status(400).json({ message: 'All fields are required: guestName, guestEmail, numGuests, tripCode' });
  }

  if (typeof numGuests !== 'number' || numGuests < 1) {
    return res.status(400).json({ message: 'numGuests must be a number greater than or equal to 1' });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(guestEmail)) {
    return res.status(400).json({ message: 'guestEmail must be a valid email address' });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode }).exec();
    if (!trip) {
      return res.status(404).json({ message: 'Trip not found for code: ' + tripCode });
    }

    const booking = new Booking({
      trip: trip._id,
      guestName,
      guestEmail,
      numGuests
    });

    await booking.save();
    return res.status(201).json(booking);

  } catch (err) {
    return res.status(500).json({ message: 'Error creating booking', error: err.message });
  }
};

// GET /api/bookings
// Returns all bookings with trip details populated
// Returns empty array if no bookings exist
const getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({}).populate('trip').exec();
    return res.status(200).json(bookings);
  } catch (err) {
    return res.status(500).json({ message: 'Error retrieving bookings', error: err.message });
  }
};

// GET /api/analytics
// Runs three aggregation pipelines and returns combined results
// Returns empty arrays if no data exists yet
const getAnalytics = async (req, res) => {
  try {

    const bookingsByTrip = await Booking.aggregate([
      {
        $group: {
          _id: '$trip',
          totalBookings: { $sum: 1 },
          totalGuests: { $sum: '$numGuests' }
        }
      },
      {
        $lookup: {
          from: 'trips',
          localField: '_id',
          foreignField: '_id',
          as: 'tripDetails'
        }
      },
      { $unwind: '$tripDetails' },
      { $sort: { totalBookings: -1 } }
    ]);

    const avgPriceByResort = await Trip.aggregate([
      {
        $group: {
          _id: '$resort',
          avgPrice: { $avg: { $toDouble: '$perPerson' } },
          tripCount: { $sum: 1 }
        }
      },
      { $sort: { avgPrice: -1 } }
    ]);

    const tripsByMonth = await Trip.aggregate([
      {
        $group: {
          _id: { $month: '$start' },
          totalTrips: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    return res.status(200).json({
      bookingsByTrip,
      avgPriceByResort,
      tripsByMonth
    });

  } catch (err) {
    return res.status(500).json({ message: 'Error retrieving analytics', error: err.message });
  }
};

module.exports = { createBooking, getBookings, getAnalytics };
