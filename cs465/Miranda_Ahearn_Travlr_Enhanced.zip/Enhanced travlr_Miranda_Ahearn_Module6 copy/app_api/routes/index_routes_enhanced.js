const express = require('express');
const router = express.Router();
const tripsController = require('../controllers/trips');
const bookingsController = require('../controllers/bookings');

// Trip routes — existing
router.route('/trips')
  .get(tripsController.tripsList)
  .post(tripsController.tripsAddTrip);

router.route('/trips/:tripCode')
  .get(tripsController.tripsReadOne)
  .put(tripsController.tripsUpdateTrip)
  .delete(tripsController.tripsDeleteTrip);

// Booking routes — new
// POST creates a booking, GET retrieves all bookings with trip details
router.route('/bookings')
  .get(bookingsController.getBookings)
  .post(bookingsController.createBooking);

// Analytics route — new
// Returns aggregation pipeline results for bookings, pricing, and trip distribution
router.route('/analytics')
  .get(bookingsController.getAnalytics);

module.exports = router;
