const express = require('express');
const router = express.Router();
const tripsController = require('../controllers/trips');
const bookingsController = require('../controllers/bookings');

router.route('/trips')
  .get(tripsController.tripsList)
  .post(tripsController.tripsAddTrip);

router.route('/trips/:tripCode')
  .get(tripsController.tripsReadOne)
  .put(tripsController.tripsUpdateTrip)
  .delete(tripsController.tripsDeleteTrip);

router.route('/bookings')
  .get(bookingsController.getBookings)
  .post(bookingsController.createBooking);

router.route('/analytics')
  .get(bookingsController.getAnalytics);

module.exports = router;
