const mongoose = require('mongoose');

// Bookings collection schema
// References the trips collection by ObjectId to establish
// a document-reference relationship between bookings and trips
const bookingSchema = new mongoose.Schema({
  trip: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'trips',
    required: true
  },
  guestName: {
    type: String,
    required: true,
    trim: true
  },
  guestEmail: {
    type: String,
    required: true,
    trim: true
  },
  numGuests: {
    type: Number,
    required: true,
    min: 1
  },
  bookedAt: {
    type: Date,
    default: Date.now
  }
});

const Booking = mongoose.model('bookings', bookingSchema);
module.exports = Booking;
